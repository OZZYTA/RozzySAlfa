<?php
	define('PREPEND_PATH', '');
	$app_dir = dirname(__FILE__);
	include_once("{$app_dir}/lib.php");

	// accept a record as an assoc array, return transformed row ready to insert to table
	$transformFunctions = [
		'covid' => function($data, $options = []) {
			if(isset($data['fecha'])) $data['fecha'] = guessMySQLDateTime($data['fecha']);
			if(isset($data['inicioasilamiento'])) $data['inicioasilamiento'] = guessMySQLDateTime($data['inicioasilamiento']);

			return $data;
		},
		'pqr' => function($data, $options = []) {
			if(isset($data['fecha'])) $data['fecha'] = guessMySQLDateTime($data['fecha']);
			if(isset($data['fechainc'])) $data['fechainc'] = guessMySQLDateTime($data['fechainc']);
			if(isset($data['cierre'])) $data['cierre'] = guessMySQLDateTime($data['cierre']);

			return $data;
		},
		'Encuesta' => function($data, $options = []) {
			if(isset($data['fecha'])) $data['fecha'] = guessMySQLDateTime($data['fecha']);

			return $data;
		},
	];

	// accept a record as an assoc array, return a boolean indicating whether to import or skip record
	$filterFunctions = [
		'covid' => function($data, $options = []) { return true; },
		'pqr' => function($data, $options = []) { return true; },
		'Encuesta' => function($data, $options = []) { return true; },
	];

	/*
	Hook file for overwriting/amending $transformFunctions and $filterFunctions:
	hooks/import-csv.php
	If found, it's included below

	The way this works is by either completely overwriting any of the above 2 arrays,
	or, more commonly, overwriting a single function, for example:
		$transformFunctions['tablename'] = function($data, $options = []) {
			// new definition here
			// then you must return transformed data
			return $data;
		};

	Another scenario is transforming a specific field and leaving other fields to the default
	transformation. One possible way of doing this is to store the original transformation function
	in GLOBALS array, calling it inside the custom transformation function, then modifying the
	specific field:
		$GLOBALS['originalTransformationFunction'] = $transformFunctions['tablename'];
		$transformFunctions['tablename'] = function($data, $options = []) {
			$data = call_user_func_array($GLOBALS['originalTransformationFunction'], [$data, $options]);
			$data['fieldname'] = 'transformed value';
			return $data;
		};
	*/

	@include("{$app_dir}/hooks/import-csv.php");

	$ui = new CSVImportUI($transformFunctions, $filterFunctions);
