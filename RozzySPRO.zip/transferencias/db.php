<?php 

$conexion=mysqli_connect("localhost","medico_web","Medicontrol123*","medico_rozzys");
?>