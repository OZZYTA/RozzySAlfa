AppGiniPlugin.language = AppGiniPlugin.language || {};
AppGiniPlugin.language.en = $j.extend(AppGiniPlugin.language.en, {
	SPECIFY_OUTPUT_FOLDER: 'SPECIFY OUTPUT FOLDER',
	


	/*************************************************************/
	end_place_holder: '--- Please keep this line at the end of the file! ---'
})