﻿$j('#ipsprim').parents('.form-group').after('<hr><b><center>1. ATENCION EN IPS<hr>');
$j('#area').parents('.form-group').after('<hr><b><center>2. PROMOCIÓN Y PREVENCIÓN<hr>');
$j('#sservicio').parents('.form-group').after('<hr><b><center>3. CALIFIQUE EL SERVICIO EN CADA UNO DE LOS SIGUIENTES ASPECTOS SEGUN LO CONSIDERE<hr>');
$j('#aspectoeps').parents('.form-group').after('<hr><b><center>4. EPS - ASPECTOS GENERALES<hr>');
$j('#farmacia').parents('.form-group').after('<hr><b><center>5. FARMACIA<hr>');
