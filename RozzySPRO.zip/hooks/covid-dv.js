

$j(function(){
	$j("label[for='s2id_autogen6']").parent().hide();
    $j('#patologia').click(function(){
         if($j(this).prop('checked')){
             /* hide some stuff */
             $j("label[for='s2id_autogen6']").parent().show();
         }else{
             /* show some stuff */
             $j("label[for='s2id_autogen6']").parent().hide();
         }
    });
});

function show_error(field, msg){
	modal_window({
		message: '<div class="alert alert-danger">' + msg + '</div>',
		title: 'Error en ' + field,
		close: function(){
			$j('#' + field).focus();
			$j('#' + field).parents('.form-group').addClass('has-error');
		}
	});
	
	return false;
}

function get_date(date_field){
	var y = $j('#' + date_field).val();
	var m = $j('#' + date_field + '-mm').val();
	var d = $j('#' + date_field + '-dd').val();
	
	var date_object = new Date(y, m - 1, d);
	
	if(!y) return false;
	
	return date_object;
}




	$j('#update, #insert').click(function(){
		/* Make sure shipped date is today or older, but not older than order date */
		var dateaislamiento = get_date('inicioasilamiento');
		var hoy = new Date();
		
		if(dateaislamiento && (dateaislamiento > hoy)){
			return show_error('fechainc', 'LA FECHA DE INICIO DEL AISLAMIENTO NO PUEDE SER FUTURA');
		}
	});

	
	

