<?php
	// check this file's MD5 to make sure it wasn't called before
	$prevMD5 = @file_get_contents(dirname(__FILE__) . '/setup.md5');
	$thisMD5 = md5(@file_get_contents(dirname(__FILE__) . '/updateDB.php'));

	// check if setup already run
	if($thisMD5 != $prevMD5) {
		// $silent is set if this file is included from setup.php
		if(!isset($silent)) $silent = true;

		// set up tables
		setupTable(
			'covid', " 
			CREATE TABLE IF NOT EXISTS `covid` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`fecha` DATE NULL,
				`tipodoc` VARCHAR(40) NOT NULL,
				`doc` INT NOT NULL,
				`nombre` VARCHAR(40) NOT NULL,
				`telefono` VARCHAR(40) NOT NULL,
				`eps` VARCHAR(40) NOT NULL,
				`regimen` VARCHAR(40) NULL,
				`aislamiento` VARCHAR(40) NOT NULL,
				`edad` MEDIUMINT(3) NOT NULL,
				`embarazo` VARCHAR(40) NOT NULL,
				`patologia` VARCHAR(40) NULL DEFAULT '0',
				`cual` TEXT NULL,
				`dx` TEXT NOT NULL,
				`sintomas` VARCHAR(40) NOT NULL,
				`inicioasilamiento` DATE NOT NULL,
				`requerido` VARCHAR(40) NOT NULL,
				`atencion` TEXT NOT NULL,
				`tratamiento` VARCHAR(40) NOT NULL,
				`medicamentos` VARCHAR(40) NOT NULL,
				`muestra` VARCHAR(40) NOT NULL,
				`donde` VARCHAR(40) NOT NULL,
				`cubrimiento` VARCHAR(40) NOT NULL,
				`vigilancia` VARCHAR(40) NOT NULL,
				`percepcion` VARCHAR(40) NOT NULL,
				`fallecido` VARCHAR(40) NULL,
				`observacion` TEXT NULL,
				`status` VARCHAR(40) NOT NULL,
				`responsable` VARCHAR(40) NULL,
				`periodo` VARCHAR(40) NULL,
				`asignado` VARCHAR(40) NULL
			) CHARSET utf8",
			$silent
		);

		setupTable(
			'pqr', " 
			CREATE TABLE IF NOT EXISTS `pqr` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`fecha` DATE NULL,
				`sac` VARCHAR(40) NULL,
				`tipoid` VARCHAR(40) NOT NULL,
				`doc` INT UNSIGNED NULL,
				`nombres` INT UNSIGNED NOT NULL,
				`apellidos` VARCHAR(40) NOT NULL,
				`telefono` VARCHAR(40) NOT NULL,
				`correo` VARCHAR(40) NOT NULL,
				`direccion` VARCHAR(100) NULL,
				`tipopqr` VARCHAR(40) NOT NULL,
				`motivo` VARCHAR(40) NOT NULL,
				`fechainc` DATE NOT NULL,
				`eps` VARCHAR(40) NOT NULL,
				`otraeps` VARCHAR(40) NULL,
				`regimen` VARCHAR(40) NULL,
				`servicio` VARCHAR(40) NOT NULL,
				`descripcion` TEXT NOT NULL,
				`estado` VARCHAR(40) NOT NULL,
				`condicion` VARCHAR(40) NOT NULL,
				`cierre` DATE NULL,
				`dias` VARCHAR(40) NULL,
				`diascierre` VARCHAR(40) NULL,
				`indicador` VARCHAR(40) NULL,
				`detalle1` TEXT NULL,
				`detalle2` TEXT NULL,
				`detalle3` TEXT NULL,
				`soportes` VARCHAR(40) NULL,
				`fallecido` VARCHAR(40) NULL,
				`status` VARCHAR(40) NOT NULL,
				`periodo` VARCHAR(40) NULL,
				`asignado` VARCHAR(40) NULL,
				`editado` VARCHAR(40) NULL,
				`encargado` VARCHAR(40) NULL,
				`ingresada` VARCHAR(40) NULL DEFAULT '1',
				`cargada` VARCHAR(40) NULL
			) CHARSET utf8",
			$silent
		);

		setupTable(
			'Encuesta', " 
			CREATE TABLE IF NOT EXISTS `Encuesta` ( 
				`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`id`),
				`fecha` DATE NULL,
				`tipoid` VARCHAR(40) NOT NULL,
				`doc` INT NOT NULL,
				`nombres` VARCHAR(40) NOT NULL,
				`apellidos` VARCHAR(40) NOT NULL,
				`eps` VARCHAR(40) NOT NULL,
				`ipsprim` VARCHAR(40) NULL,
				`tratoser` VARCHAR(40) NOT NULL,
				`cita` VARCHAR(40) NOT NULL,
				`tratoasis` VARCHAR(40) NOT NULL,
				`expprof` VARCHAR(40) NOT NULL,
				`bioser` VARCHAR(40) NOT NULL,
				`area` VARCHAR(40) NOT NULL,
				`pyp` VARCHAR(40) NOT NULL,
				`prenatal` VARCHAR(40) NOT NULL,
				`cyd` VARCHAR(40) NOT NULL,
				`vacunas` VARCHAR(40) NOT NULL,
				`pfm` VARCHAR(40) NOT NULL,
				`citologia` VARCHAR(40) NOT NULL,
				`sservicio` VARCHAR(40) NOT NULL,
				`incomodo` VARCHAR(40) NOT NULL,
				`otro` VARCHAR(40) NULL,
				`why` TEXT NULL,
				`urgencia` VARCHAR(40) NOT NULL,
				`citaoportuna` VARCHAR(40) NOT NULL,
				`aspectoeps` VARCHAR(40) NOT NULL,
				`fisicas` VARCHAR(40) NOT NULL,
				`aseo` VARCHAR(40) NOT NULL,
				`capacitacion` VARCHAR(40) NOT NULL,
				`autorizaciones` VARCHAR(40) NOT NULL,
				`general` VARCHAR(40) NOT NULL,
				`horario` VARCHAR(40) NOT NULL,
				`formulario` VARCHAR(40) NOT NULL,
				`farmacia` VARCHAR(40) NOT NULL,
				`fisicasfarma` VARCHAR(40) NOT NULL,
				`oporfarmacia` VARCHAR(40) NOT NULL,
				`totalidad` VARCHAR(40) NOT NULL,
				`cambio` VARCHAR(40) NOT NULL,
				`volver` VARCHAR(40) NOT NULL,
				`orientacion` VARCHAR(40) NOT NULL,
				`embalaje` VARCHAR(40) NOT NULL,
				`revision` VARCHAR(40) NOT NULL,
				`observaciones` TEXT NULL,
				`user` VARCHAR(40) NULL
			) CHARSET utf8",
			$silent
		);



		// save MD5
		@file_put_contents(dirname(__FILE__) . '/setup.md5', $thisMD5);
	}


	function setupIndexes($tableName, $arrFields) {
		if(!is_array($arrFields) || !count($arrFields)) return false;

		foreach($arrFields as $fieldName) {
			if(!$res = @db_query("SHOW COLUMNS FROM `$tableName` like '$fieldName'")) continue;
			if(!$row = @db_fetch_assoc($res)) continue;
			if($row['Key']) continue;

			@db_query("ALTER TABLE `$tableName` ADD INDEX `$fieldName` (`$fieldName`)");
		}
	}


	function setupTable($tableName, $createSQL = '', $silent = true, $arrAlter = '') {
		global $Translation;
		$oldTableName = '';
		ob_start();

		echo '<div style="padding: 5px; border-bottom:solid 1px silver; font-family: verdana, arial; font-size: 10px;">';

		// is there a table rename query?
		if(is_array($arrAlter)) {
			$matches = [];
			if(preg_match("/ALTER TABLE `(.*)` RENAME `$tableName`/i", $arrAlter[0], $matches)) {
				$oldTableName = $matches[1];
			}
		}

		if($res = @db_query("SELECT COUNT(1) FROM `$tableName`")) { // table already exists
			if($row = @db_fetch_array($res)) {
				echo str_replace(['<TableName>', '<NumRecords>'], [$tableName, $row[0]], $Translation['table exists']);
				if(is_array($arrAlter)) {
					echo '<br>';
					foreach($arrAlter as $alter) {
						if($alter != '') {
							echo "$alter ... ";
							if(!@db_query($alter)) {
								echo '<span class="label label-danger">' . $Translation['failed'] . '</span>';
								echo '<div class="text-danger">' . $Translation['mysql said'] . ' ' . db_error(db_link()) . '</div>';
							} else {
								echo '<span class="label label-success">' . $Translation['ok'] . '</span>';
							}
						}
					}
				} else {
					echo $Translation['table uptodate'];
				}
			} else {
				echo str_replace('<TableName>', $tableName, $Translation['couldnt count']);
			}
		} else { // given tableName doesn't exist

			if($oldTableName != '') { // if we have a table rename query
				if($ro = @db_query("SELECT COUNT(1) FROM `$oldTableName`")) { // if old table exists, rename it.
					$renameQuery = array_shift($arrAlter); // get and remove rename query

					echo "$renameQuery ... ";
					if(!@db_query($renameQuery)) {
						echo '<span class="label label-danger">' . $Translation['failed'] . '</span>';
						echo '<div class="text-danger">' . $Translation['mysql said'] . ' ' . db_error(db_link()) . '</div>';
					} else {
						echo '<span class="label label-success">' . $Translation['ok'] . '</span>';
					}

					if(is_array($arrAlter)) setupTable($tableName, $createSQL, false, $arrAlter); // execute Alter queries on renamed table ...
				} else { // if old tableName doesn't exist (nor the new one since we're here), then just create the table.
					setupTable($tableName, $createSQL, false); // no Alter queries passed ...
				}
			} else { // tableName doesn't exist and no rename, so just create the table
				echo str_replace("<TableName>", $tableName, $Translation["creating table"]);
				if(!@db_query($createSQL)) {
					echo '<span class="label label-danger">' . $Translation['failed'] . '</span>';
					echo '<div class="text-danger">' . $Translation['mysql said'] . db_error(db_link()) . '</div>';
				} else {
					echo '<span class="label label-success">' . $Translation['ok'] . '</span>';
				}
			}
		}

		echo '</div>';

		$out = ob_get_clean();
		if(!$silent) echo $out;
	}
