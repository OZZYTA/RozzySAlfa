<?php
function php_func(){
    echo " Have a great day";
}
php_func();
?>