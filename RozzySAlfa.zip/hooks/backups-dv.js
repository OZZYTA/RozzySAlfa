$j(function() {
$j('#resConsecutivo').click(function(){ {
alert("probando 1 2 3")
}

})