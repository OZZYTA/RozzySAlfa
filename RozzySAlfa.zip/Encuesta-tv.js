$j('#ipsprim').parents('.form-group').after('<hr>Atencion<hr>');

