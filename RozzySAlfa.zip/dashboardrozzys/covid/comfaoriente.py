# Import required libraries
import pymysql
import pandas as pd
import streamlit as st
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import matplotlib.pyplot as plt
from plotly.subplots import make_subplots
import datetime


# @st.cache(suppress_st_warning=True)
# @st.cache(allow_output_mutation=True)

def app():
    st.header('SEGUIMIENTO DE ATENCION USUARIOS EN AISLAMIENTO PREVENTIVO OBLIGATORIO - COMFAORIENTE')
#     st.subheader("Listado de PQR")
    connection = pymysql.connect(host='107.180.43.4',
                                user='medico_web',
                                password='Medicontrol123*',
                                db='medico_rozzys',
                                cursorclass=pymysql.cursors.DictCursor)
    cursor = connection.cursor()
    sql = "SELECT * FROM covid"
    df = pd.read_sql(sql, connection)
    cursor.execute(sql)
    result = cursor.fetchone()
    connection.close()
    
    df=df[(df['fecha'] != "0000-00-00")]
    df['fecha'] =  pd.to_datetime(df['fecha'], format='%Y-%m-%d')
    df['inicioasilamiento'] =  pd.to_datetime(df['inicioasilamiento'], format='%Y-%m-%d')
    df['mesaislamiento']=df['inicioasilamiento'].dt.strftime("%m")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("01", "Enero")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("02", "Febrero")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("03", "Marzo")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("04", "Abril")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("05", "Mayo")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("06", "Junio")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("07", "Julio")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("08", "Agosto")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("09", "Septiembre")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("10", "Octubre")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("11", "Noviembre")
    df['mesaislamiento']=df['mesaislamiento'].str.replace("12", "Diciembre")
    df['eps']=df['eps'].str.replace('COMFAORIENTE EPS','COMFAORIENTE')
    dfcomfaoriente=df[(df['eps'] == "COMFAORIENTE")]
    full=len(dfcomfaoriente)
    st.write("Al día de hoy, Medicontrol SAS ha encuestado en total a ",full," afiliados, pertenecientes a las bases de datos de pacientes población objeto de control establecidos en el numeral 4 de la Resolución 521 de 2020, con el objetivo de conocer su experiencia con respecto a la atención y medidas tomadas por la EPS durante el Aislamiento Preventivo Obligatorio.")
    
    st.write("Por favor seleccione el rango de fechas que desea consultar:")
    today = datetime.date.today()
    tomorrow = today + datetime.timedelta(days=1)
    start_date = st.date_input('Fecha Inicial', datetime.date(2020,7,1))
    start_date=np.datetime64(start_date)
    end_date = st.date_input('Fecha Final', datetime.date(2020,12,1))
    end_date=np.datetime64(end_date) 
    
    dfcomfaoriente['inicioasilamiento'] = pd.to_datetime(dfcomfaoriente['inicioasilamiento'], format='%Y-%m-%d')
    mask = (dfcomfaoriente['inicioasilamiento'] > start_date) & (dfcomfaoriente['inicioasilamiento'] <= end_date)
    dfcomfaoriente = dfcomfaoriente.loc[mask]
    
    dfver=dfcomfaoriente[(dfcomfaoriente['fecha'] != "0000-00-00")]
    total=len(dfcomfaoriente)
    ver=len(dfver)
 
    st.write("De los ",full, " Pacientes encuestados, ",ver," Se encontraban en aislamiento preventivo obligatorio en los periodos comprendidos entre las fechas ",start_date," y ",end_date,", A estos se les hizo preguntas puntuales sobre la atención ofrecida por su EAPB, asi como el manejo dado a la entrega de sus medicamentos y el control, seguimiento y vigilancia de su estado de salud. Y a continuación se muestran los resultados encontrados a partir del análisis realizado.")
    is_check = st.checkbox("Ver Tabla de Encuestados")
    if is_check:
        st.write(dfver)
    
    periodo=dfver.groupby('mesaislamiento').count().reset_index()
    periodo=periodo.sort_values('eps', ascending=False)
    xperiodo=periodo['mesaislamiento']
    yperiodo=periodo.eps
    fig1 = px.pie(values=yperiodo, names=xperiodo)
    fig1.update_layout(showlegend=False)
    
    dfver['patologia']=dfver['patologia'].str.replace('0','SIN PATOLOGIA') 
    dfver['patologia']=dfver['patologia'].str.replace('1','CON PATOLOGIA') 
    patologia=dfver.groupby('patologia').count().reset_index()
    patologia=patologia.sort_values('eps', ascending=False)
    xpatologia=patologia['patologia']
    ypatologia=patologia.eps
    fig2 = px.pie(values=ypatologia, names=xpatologia) 
    fig2.update_layout(showlegend=False)
    
    dfver['mayor']=dfver.edad>70
    dfver['mayor']=dfver['mayor'].astype(str)
    dfver['mayor']=dfver['mayor'].str.replace('True','Mayor de 70 años') 
    dfver['mayor']=dfver['mayor'].str.replace('False','Menor de 70 años') 
    mayor=dfver.groupby('mayor').count().reset_index()
    mayor=mayor.sort_values('eps', ascending=False)
    xmayor=mayor['mayor']
    ymayor=mayor.eps
    fig3 = px.pie(values=ymayor, names=xmayor)
    fig3.update_layout(showlegend=False)
    
    fig4 = px.histogram(dfver, x="atencion")
    fig4.update_layout(showlegend=False)
    
    fig6 = px.histogram(dfver, x="tratamiento")
    fig7 = px.histogram(dfver, x="medicamentos")
    fig8 = px.histogram(dfver, x="percepcion", width=150, height=300)
    
    col1, col2 = st.beta_columns(2)
    with col1:
        st.subheader("Periodo de Aislamiento")
        st.write("Aqui puede observar el histograma del periodo en el que el usuario manifiesta haber iniciado su Aislamiento Preventivo Obligatorio")
        st.plotly_chart(fig1, use_container_width=True)
    with col2:
        st.subheader("Patología de base")
        st.write("Al consultarle a los encuestados si sufrian de alguna patología de base o condición cronica, los mismos respondieron de la siguiente manera:")
        st.plotly_chart(fig2, use_container_width=True)
    
    col3, col4 = st.beta_columns(2)
    with col3:
        st.subheader("Edad del Encuestado")
        st.write("Considerando los usuarios mayores de 70 años como pacientes objeto de control, se encuentra que de los encuestados los mayores de 70 años vienes dados en la siguiente proporción:")
        st.plotly_chart(fig3, use_container_width=True)
    with col4:
        st.subheader("Tipo de Atención Recibida")
        st.write("Se le pregunta a los usuarios encuestados si durante su periodo de aislamiento preventivo obligatorio necesitaron de atención medica, y en caso afirmativo, qué tipo de atención habia brindado la EPS, o si por el contrario no recibió ninguna atención.")
        st.plotly_chart(fig4, use_container_width=True)
        
    
    st.subheader("Indicador de satisfacción")
    st.write("Después de verificar con los usuarios y confirmar cuales de las PQR radicadas durante el periodo seleccionado se encontraban resueltas y cerradas, se consulto el estado de satisfacción del usuario con respecto a la resolución brindada por parte de la EAPB.")
    st.plotly_chart(fig5, use_container_width=True)
    
    st.write("Si desea consultar el detalle de cada PQR, por favor ingrese al aplicativo RozzyS con su nombre de usuario y contraseña.")
    link = '[RozzyS](http://rozzys.medicontrolsas.com)'
    st.markdown(link, unsafe_allow_html=True)
    

